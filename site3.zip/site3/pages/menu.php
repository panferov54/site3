
<ul class="nav nav-pills justify-content-around w-100" role="tablist" >
    <li class="nav-item"><a href="index.php?page=1" class="nav-link <?php echo ($_GET['page']==='1')?"active":""?> text-white" role="tab" >Каталог</a></li>
    <li class="nav-item"><a href="index.php?page=2"  class="nav-link <?php echo ($_GET['page']==='2')?"active":""?> text-white" role="tab">Корзина</a></li>
    <li class="nav-item"><a href="index.php?page=3"  class="nav-link <?php echo ($_GET['page']==='3')?"active":""?> text-white" role="tab">Регистрация</a></li>
    <li class="nav-item"><a href="index.php?page=4"   class="nav-link <?php echo ($_GET['page']==='4')?"active":""?> text-white" role="tab">Панель Администрирования</a></li>

</ul>





<?php
