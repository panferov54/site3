<h3>Каталог товаров</h3>

<?php
var_dump(Item::getItems());
