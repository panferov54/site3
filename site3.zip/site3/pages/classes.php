<?php
class Tools{
   static public function connect($host="localhost:8889",$user="root",$pass="root",$dbname="shop"){

      //PDO(PHP data object)- механизм взаимодействия с СУБД
       //ПДО позволяет облегчить рутинные задачи при выполнение запросов и содержит защитные механизмы при работе с субд


       //определим DSN - сведения для подключения к БД
        $cs="mysql:host=$host;dbname=$dbname;charset=utf8";
        //массив опций для создания PDO
       $option=[
           PDO::ATTR_ERRMODE =>PDO::ERRMODE_EXCEPTION,
           PDO::ATTR_DEFAULT_FETCH_MODE =>PDO::FETCH_ASSOC,
           PDO::MYSQL_ATTR_INIT_COMMAND=>'SET NAMES UTF8'
       ];


       try {
           $pdo=new PDO($cs,$user,$pass,$option);
           return $pdo;

       }catch (PDOException $e){
           echo $e->getMessage();
           return false;
       }
    }
};

class Customer {
    public $id;
    public $login;
    public $pass;
    public $roleid;
    public $discount;
    public $total;
    public $imagepath;

    function __construct($login,$pass,$imagepath,$id=0){
        $this->login=trim($login);
        $this->pass=trim($pass);
        $this->imagepath=$imagepath;
        $this->id=$id;

        $this->total=0;
        $this->discount=0;
        $this->roleid=2;
    }

    function register(){
        if ($this->login===''||$this->pass===''){
            echo '<h3 class="text-danger">заполните все поля</h3>';
            return false;
        }
        if (strlen($this->login)<3||strlen($this->login)>32||strlen($this->pass)>64){
            echo "<h4 class='text-danger'>не корректрна длина полей</h4>";
            return false;

        }
$this->intoDb();
        return true;

    }

    function intoDb(){
        try {
            $pdo=Tools::connect();
            //подготовим запрос на добавление польхователя
            $ps=$pdo->prepare("INSERT INTO customers(login,pass,roleid,discount,total,imagepath) values (:login,:pass,:roleid,:discount,:total,:imagepath)");
           //разименовывание объекта this и преобразование к массиву
           $ar=(array)$this;
           array_shift($ar);//удаляем первый элемент массива
        $ps->execute($ar);

        }catch (PDOException $e){
            echo $e->getMessage();
            return false;
        }
    }
};

class Item {
    public $id;
    public $itemname;
    public $catid;
    public $pricein;
    public $pricesale;
    public $info;
    public $rate;
    public $imagepath;
    public $action;

    function __construct($itemname,$catid,$pricein,$pricesale,$info,$imagepath,$rate=0,$action=0,$id=0)
    {
        $this->id=$id;
        $this->itemname=$itemname;
        $this->catid=$catid;
        $this->pricein=$pricein;
        $this->pricesale=$pricesale;
        $this->info=$info;
        $this->rate=$rate;
        $this->imagepath=$imagepath;
        $this->action=$action;
    }

    function intoDb(){

        try {
            $pdo=Tools::connect();
            $ps=$pdo->prepare("insert into items(itemname,catid,pricein,pricesale,info,rate,imagepath,action) values (:itemname,:catid,:pricein,:pricesale,:info,:rate,:imagepath,:action)");
        $ar=(array)$this;
            array_shift($ar);
            $ps->execute($ar);
        }catch (PDOException $e){
            echo $e->getMessage();
            return false;
        }
    }
    static function fromDb($id){
        try {
            $pdo=Tools::connect();
            $ps=$pdo->prepare("select * from items where id=?");
        $ps->execute([$id]);
        $row=$ps->fetch();
        $item= new Item($row['itemname'],$row['catid'],$row['pricein'],$row['pricesale'],$row['info'],$row['imagepath'],$row['rate'],$row['action'],$row['id']);
     return $item;
        }catch (PDOException $e){
            echo $e->getMessage();
            return false;
        }
    }

    //метод формирования списка товаров
  static function getItems($catid=0){
       try {
           $pdo=Tools::connect();
          //если категория не выбрана, то показываем все товары
           if ($catid===0){
               $ps=$pdo->query("select * from items");

           } else {
               //если catid есть, то фильтруем по нему
               $ps=$pdo->prepare("select * from items where catid=?");
               $ps->execute([$catid]);
           }
           while ($row=$ps->fetch()){
               $item= new Item($row['itemname'],$row['catid'],$row['pricein'],$row['pricesale'],$row['info'],$row['imagepath'],$row['rate'],$row['action'],$row['id']);
              //создаем массив экземпляров класса Item
               $items[]=$item;
           }
           return $items;
       }catch (PDOException $e){
           echo $e->getMessage();
           return false;
       }

   }

    //  метод отрисовки товаров
    function drawItem(){



    }

}